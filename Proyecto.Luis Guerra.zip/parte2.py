from Constructor import Constructor
from Carrera import Carrera, Locacion, Circuito
from Piloto import Piloto
import random


def val_ocupado(mapa, fila, columna):
  ''' Determina si el puesto estaba ocupado '''

  f = 0
  for x in mapa:
    f += 1
    if f == (int(fila)):
      c = 0
      for y in x:
        c += 1
        if c == (int(columna)):
          if y == False:
            mapa[f - 1][c - 1] = True
            return True
          else:
            return False


def imprimir_mapa(mapa):
  ''' Imprime el mapa de la carrera a elegir "Gestion de venta de entradas" '''

  print("\n")
  print("* " * len(mapa[0]) + "CARERRA " + "* " * len(mapa[0]))
  print("\n")
  nums = "    "
  for i, x in enumerate(mapa[0]):
    if i > 8:
      nums += str(i + 1) + "| "
    else:
      nums += str(i + 1) + " | "
  print(nums)
  for i, x in enumerate(mapa):
    if i > 8:
      auxiliar = str(i + 1)
    else:
      auxiliar = str(i + 1) + " "
    for y in x:
      if y == True:
        auxiliar += "| X "
      else:
        auxiliar += "|   "
    print("   " + "-" * len(mapa[0] * 4))
    print(auxiliar)


def generar_codigo():
  ''' Genera un codigo aleatorio de 5 digitos "Gestion de venta de entradas" '''
  letras = "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTuUVWXYZ"
  numeros = "0123456789"
  simbolos = ".@€!$%/()=?¿{}[]/"
  unir = f"{letras}{numeros}{simbolos}"
  extension = random.sample(unir, 5)
  codigo = "".join(extension)
  return codigo


def descuento_50(precio):
  ''' Genera un precio con descuento del 50% "Gestion de venta de entradas" '''
  descuento = precio * (50 / 100)
  precio_2 = precio - descuento
  return precio_2


def iva(precio, subtotal):
  ''' Genera un precio con IVA del 16% "Gestion de venta de entradas" '''
  descuento = subtotal * (16 / 100)
  precio_final = precio + descuento
  return precio_final


def num_ondulado(cedula, precio):
  ''' Comprueba si la cedula es un numero ondulado y aplica el descuento del 50% "Gestion de venta de entradas" '''
  if str(cedula)[0] == str(cedula)[2]:
    print("Felicidades ha obtenido un descuento del 50%!!")
    return descuento_50(precio)
  else:
    return precio


def ver_carreras(lista_locacion, edca):
  ''' Muestra las carreras con sus locaciones y circuitos "Gestion de venta de entradas" '''
  for i, x in enumerate(lista_locacion):
    print(f"\n-{i + 1}")
    x.mostrar()


def solicitar_datos(lista_locacion, edca, lista_carreras):
  ''' Pide los datos del usuario para registrarlo en la db.txt "Gestion de venta de entradas" '''
  asientos = []
  codigo_aletorio = generar_codigo()

  print("\n--- Bienvenido a la compra de entradas!! ---\n")
  print("Porfavor ingrese los siguientes datos:")
  nombre = input("Ingrese su nombre: ").title()
  while not ("".join(nombre.split(" "))).isalpha():
    nombre = input("Ingreso inválido, ingrese su nombre: ").title()
  cedula = input("Ingrese su número de cédula (sin caracteres especiales): ")
  while (not cedula.isnumeric()) or (int(cedula) < 100):
    cedula = input("Ingreso inválido, ingrese su número de cédula: ")
  edad = input("Ingrese su edad: ")
  while (not edad.isnumeric()) or (int(edad) < 1) or (int(edad) > 100):
    edad = input("Ingreso inválido, ingrese su edad: ")
  print("----Estas son las carreras----")

  ver_carreras(lista_locacion, edca)
  num_de_carrera = input(
    "Ingrese el numero de la carrera a la que desea comprar ticket: ")
  while (not num_de_carrera.isnumeric()) or (int(num_de_carrera) <
                                             1) or (int(num_de_carrera) > 23):
    num_de_carrera = input(
      "Ingreso inválido, ingrese el numero de la carrera a la que desea comprar ticket: "
    )

  print("\nIngrese el tipo de entrada que desea comprar: \n")
  tip_entrada = input(
    "1-General: solo podrá ver la carrera en su asiento y su precio es de $150\n\n2-VIP: podrá disfrutar del restaurante del circuito y su precio es de $340\n>>"
  )
  while tip_entrada != "1" and tip_entrada != "2":
    tip_entrada = input(
      "Ingreso invalido, ingrese el tipo de entrada que desea comprar:")
  if tip_entrada == "1":
    tip_entrada = "General"
    precio = 150
    subtotal = 150

  elif tip_entrada == "2":
    precio = 340
    subtotal = 340
    tip_entrada = "VIP"

  for i, x in enumerate(lista_carreras):
    if int(num_de_carrera) == i + 1:
      if tip_entrada == "General":
        mapa = x.mapa_general

        imprimir_mapa(mapa)
      elif tip_entrada == "VIP":
        mapa = x.mapa_vip

        imprimir_mapa(mapa)

  fila = input("\nIngrese la fila: ")
  while (not fila.isnumeric()) or (int(fila) < 1) or (int(fila) > len(mapa)):
    fila = input("\nERROR!!, ingrese la fila: ")

  columna = input("\nIngrese la columna: ")
  while (not columna.isnumeric()) or (int(columna) < 1) or (int(columna) > len(
      mapa[0])):
    columna = input("ERROR!!, ingrese la columna: ")

  puede = val_ocupado(mapa, fila, columna)

  if puede:
    pass

  else:
    print(
      f"\n!! EL ASIENTO ESCOGIDO YA ESTA OCUPADO\nPORFAVOR SELECCIONE OTRO ASIENTO"
    )
    fila = input("\nIngrese la fila: ")
    while (not fila.isnumeric()) or (int(fila) < 1) or (int(fila) > len(mapa)):
      fila = input("\nERROR!!, ingrese la fila: ")

    columna = input("\nIngrese la columna: ")
    while (not columna.isnumeric()) or (int(columna) < 1) or (int(columna) >
                                                              len(mapa[0])):
      columna = input("ERROR!!, ingrese la columna: ")

  fila = int(fila)
  columna = int(columna)

  asiento = [fila, columna]
  precio = num_ondulado(cedula, precio)
  precio_final = iva(precio, subtotal)

  print(f"\nEl costo de su entrada es: {precio_final}$\n")

  if precio == subtotal:
    descuento = 0
  else:
    descuento = subtotal * (50 / 100)
  IVA = subtotal * (16 / 100)
  print("------------------------------------")
  print(
    f"Su asiento es para la carrera #{num_de_carrera}: \nFila #{fila} en la Columna #{columna}\n"
  )
  print("-------------Factura----------------")
  print(f"Subtotal: {subtotal}$")
  print(f"Descuento: {descuento}$")
  print(f"IVA:{IVA}$")
  print("------------------------------------")
  print(f"Total: {precio_final}$")
  print("------------------------------------")
  print("Desea proceder a pagar la entrada? ")
  asistencia = False
  gastado_restaurant = 0
  finalizar = input("Ingrese\n1-Si\n2-No\n>>")
  while finalizar != "1" and finalizar != "2":
    finalizar = input("Ingreso invalido, ingrese\n1-Si\n2-No\n>>")

  if finalizar == "1":
    mapa[int(fila) - 1][int(columna) - 1] = True
    print("Pago exitoso!!")
    with open("db.txt", "a+") as db:
      db.write(
        f"{nombre}//{cedula}//{edad}//{num_de_carrera}//{tip_entrada}//{precio_final}//{asiento}//{codigo_aletorio}//{asistencia}//{gastado_restaurant}\n"
      )
    db.close()

  elif finalizar == "2":
    mapa[int(fila) - 1][int(columna) - 1] = False
