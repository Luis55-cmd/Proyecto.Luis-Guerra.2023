from Restaurante import Restaurante
from Comida import Comida, Bebida, Alimento
from Boleto import Boleto
from Cliente import Cliente


def validar_cliente(lista_comida, lista_restaurantes, clientes):
  ''' Valida que la cedula ingresada pertenezca a un cliente "Gestion de venta de restaurante" '''

  print("\n\t--- MENU GESTION DE VENTA DE RESTAURANTES ---\n")

  ingresar_cedula = input(
    "Ingrese su número de cédula (sin caracteres especiales): ")
  while (not ingresar_cedula.isnumeric()) or (int(ingresar_cedula) < 100):
    ingresar_cedula = input("Ingreso inválido, ingrese su número de cédula: ")
  try:
    with open("db.txt") as db:
      datos = db.readlines()
    if len(datos) == 0:
      print("\nTodavía no hay ningúna compra.\n")
    else:
      for dato in datos:
        factura = dato[:-1].split("//")

  except FileNotFoundError:
    print("\nTodavía no hay ningúna compra.\n")

  comidas = ""
  edad = ""
  for i, dato in enumerate(datos):
    factura = dato[:-1].split("//")

    if str(ingresar_cedula) == factura[1]:

      if factura[4] == "VIP":
        ne = i + 1
        edad = factura[2]
        print("\n----Estos son los restaurantes de comida----")

        for i, a in enumerate(lista_restaurantes):
          print(f"\n{i + 1}- {a.name}")
        seleccion_restaurante = input(
          "\nIngrese el numero del restaurante a elegir: ")
        while (not seleccion_restaurante.isnumeric()) or int(
            seleccion_restaurante) < 1 or int(seleccion_restaurante) > 93:
          seleccion_restaurante = input("""
Ingreso invalido!!
Porfavor seleccione un restaurante:
>>""")
        seleccion_restaurante = int(seleccion_restaurante)
        for i, a in enumerate(lista_restaurantes):
          if seleccion_restaurante == i + 1:
            print("\n")
            a.mostrar_items()

        seleccion = input("Ingrese el numero de la comida a elegir: ")
        while (not seleccion.isnumeric()
               ) or int(seleccion) < 1 or int(seleccion) > len(a.items):
          seleccion = input("""
Ingreso invalido!!
Porfavor seleccione una comida:
>>""")
        seleccion = int(seleccion)
        for i, a in enumerate(lista_restaurantes):
          if seleccion_restaurante == i + 1:
            for i, b in enumerate(a.items):
              if seleccion == i + 1:
                tipo = b["type"].split(":")
                if tipo[1] == "alcoholic" and int(edad) < 18:
                  print(
                    "\nLa edad del cliente es menor a 18 años no puede elegir bebidas alcohólicas\n"
                  )
                  seleccion = input(
                    "Porfavor vuelva a ingresar la comida a elegir: ")
                  while (not seleccion.isnumeric()
                         ) or int(seleccion) < 1 or int(seleccion) > 100:
                    seleccion = input("""
                    Ingreso invalido!!
                    Porfavor seleccione una comida:
                    >>""")
                  seleccion = int(seleccion)
                  for i, a in enumerate(lista_restaurantes):
                    if seleccion_restaurante == i + 1:
                      for i, b in enumerate(a.items):
                        if seleccion == i + 1:
                          tipo = b["type"].split(":")

                else:
                  for i, a in enumerate(lista_restaurantes):
                    if seleccion_restaurante == i + 1:
                      for i, b in enumerate(a.items):
                        if seleccion == i + 1:
                          tipo = b["type"].split(":")
                          comidas = b
                          clientes.append(Cliente(ingresar_cedula, comidas))

                for i, a in enumerate(lista_restaurantes):
                  if seleccion_restaurante == i + 1:
                    for i, b in enumerate(a.items):
                      if seleccion == i + 1:
                        nombre = b["name"]
                for x in lista_comida:
                  if x.nombre_comida == nombre:
                    for y in clientes:
                      y.comidas_compradas.append(x)

        while True:
          volver_a_preguntar = input(
            "Desea agregar otro producto?\n1-Si\n2-No\n>>")
          while volver_a_preguntar != "1" and volver_a_preguntar != "2":
            volver_a_preguntar = input(
              "Ingreso invalido, porfavor ingrese\n1-Si\n2-No\n>>")
          if volver_a_preguntar == "1":
            seleccion = input("Ingrese el numero de la comida a elegir: ")
            while (not seleccion.isnumeric()
                   ) or int(seleccion) < 1 or int(seleccion) > 100:
              seleccion = input("""
            Ingreso invalido!!
            Porfavor seleccione una comida:
            >>""")
            seleccion = int(seleccion)
            for i, a in enumerate(lista_restaurantes):
              if seleccion_restaurante == i + 1:
                for i, b in enumerate(a.items):
                  if seleccion == i + 1:
                    tipo = b["type"].split(":")
                    while True:
                      if tipo[1] == "alcoholic" and int(edad) < 18:
                        print(
                          "\nLa edad del cliente es menor a 18 años no puede elegir bebidas alcohólicas\n"
                        )
                        seleccion = input(
                          "Porfavor vuelva a ingresar la comida a elegir: ")
                        while (not seleccion.isnumeric()
                               ) or int(seleccion) < 1 or int(seleccion) > 100:
                          seleccion = input("""
                        Ingreso invalido!!
                        Porfavor seleccione una comida:
                        >>""")
                        seleccion = int(seleccion)
                        for i, a in enumerate(lista_restaurantes):
                          if seleccion_restaurante == i + 1:
                            for i, b in enumerate(a.items):
                              if seleccion == i + 1:
                                tipo = b["type"].split(":")

                      else:
                        break
                    for i, a in enumerate(lista_restaurantes):
                      if seleccion_restaurante == i + 1:
                        for i, b in enumerate(a.items):
                          if seleccion == i + 1:
                            nombre = b["name"]

                    for x in lista_comida:
                      if x.nombre_comida == nombre:
                        for y in clientes:
                          y.comidas_compradas.append(x)
          else:
            break

        ingresar_cedula = int(ingresar_cedula)
        precio_f = 0
        print("\nEstos son los productos que desea comprar:\n")
        print("-------------------------------------------------")

        for y in clientes:
          m = y.comidas_compradas

          for i, j in enumerate(m):
            print(f"\n-{i + 1}")
            j.mostrar()
            print("-------------------------------------------------")
            precio_f += j.precio
        print("Este es el monto total: ",
              round(perfecto(ingresar_cedula, precio_f), 2), "$")
        print("-------------------------------------------------\n")
        print("Desea proceder con la compra? ")
        finalizar = input("Ingrese\n1-Si\n2-No\n>>")
        while finalizar != "1" and finalizar != "2":
          finalizar = input("Ingreso invalido, ingrese\n1-Si\n2-No\n>>")
        if finalizar == "1":
          if precio_f == perfecto(ingresar_cedula, precio_f):
            descuento = 0
          else:
            descuento = precio_f * (15 / 100)
          print("\nPago exitoso!!\n")

          print("-------------Factura----------------")
          print(f"Subtotal: {round(precio_f,2)}$")
          print(f"Descuento: {round(descuento,2)}$")
          print("------------------------------------")
          print(f"Total: {round(perfecto(ingresar_cedula,precio_f),2)}$")
          print("------------------------------------\n")
          restar_del_invetario_productos_comprados(lista_comida, clientes)
        elif finalizar == "2":
          pass

        gastado_restaurante = round(perfecto(ingresar_cedula, precio_f), 2)

        with open("db.txt") as dbe:
          datos = dbe.readlines()
        for i, dato in enumerate(datos):

          if i == (ne - 1):
            e = dato[:-1].split("//")

            aux = e

        aux[9] = gastado_restaurante

        with open("db.txt") as dbe:
          datos = dbe.readlines()
        for i in range(len(datos)):
          if i == (ne - 1):

            datos[
              ne -
              1] = f"{aux[0]}//{aux[1]}//{aux[2]}//{aux[3]}//{aux[4]}//{aux[5]}//{aux[6]}//{aux[7]}//{aux[8]}//{aux[9]}\n"
        with open("db.txt", "w") as dbe:

          dbe.writelines(datos)
        db.close()
      else:
        print("\nEste cliente no tiene entrada VIP\n")


def restar_del_invetario_productos_comprados(lista_comida, clientes):
  ''' Resta del inventario del restaurant el producto comprado por el cliente "Gestion de venta de restaurante" '''
  for x in lista_comida:

    for y in clientes:
      for i, j in enumerate(y.comidas_compradas):
        if j == x:
          x.cantidad -= 1
        if x.cantidad == 0:
          x.cantidad = "Sin producto"


def perfecto(cedula, precio):
  ''' Comprueba si la cedula es un numero perfecto y aplica el descuento del 15% "Gestion de venta de restaurante" '''

  divisores = []
  for d in range(1, cedula):
    if cedula % d == 0:
      divisores.append(d)
  if sum(divisores) == cedula:
    return descuento_15(precio)
  else:
    return precio


def descuento_15(precio):
  ''' Genera un precio con descuento del 15% "Gestion de venta de restaurante" '''
  descuento = precio * (15 / 100)
  precio_final = precio - descuento
  return precio_final
