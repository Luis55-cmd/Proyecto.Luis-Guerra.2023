import requests
import json
import random
import matplotlib
import matplotlib.pyplot as p
from Constructor import Constructor
from Carrera import Carrera, Locacion, Circuito
from Piloto import Piloto
from Restaurante import Restaurante
from Comida import Comida, Bebida, Alimento
from Boleto import Boleto
from Cliente import Cliente
from parte1 import *
from parte2 import *
from parte3 import *
from parte4 import *
from parte5 import *
from parte6 import *


def crear_mapa(filas, columnas):
  ''' Crea la matriz del mapa '''

  mapa = []
  for y in range(filas):
    aux = []
    for x in range(columnas):
      aux.append(False)
    mapa.append(aux)
  return mapa


"---------------------------------------------"


def pasar_estructura_a_objetos(edc, edp, edca, lista_constructores,
                               lista_pilotos, lista_carreras, lista_circuitos,
                               lista_locacion, lista_comida,
                               lista_bebida_noalcohol, lista_bebida_alcohol,
                               lista_alimento_fast, lista_alimento_restaurant,
                               lista_restaurantes):
  ''' Toma la estructura de las apis, convierte cada elemento en un objeto y lo agrega a una nueva estructura '''

  for x in edp:
    lista_pilotos.append(
      Piloto(x["id"], x["permanentNumber"], x["code"], x["team"],
             x["firstName"], x["lastName"], x["dateOfBirth"], x["nationality"],
             0))

  for x in edc:
    piloto = []
    for y in edp:
      if x["id"] == y["team"]:
        piloto.append(y)
        pass
    lista_constructores.append(
      Constructor(x["id"], x["name"], x["nationality"], piloto, 0))

  for x in edca:
    mapa = x["map"]
    for key, value in mapa.items():

      if key == "general":
        filas = value[0]
        columnas = value[1]
        mapa_general = crear_mapa(filas, columnas)

      else:
        filas = value[0]
        columnas = value[1]
        mapa_vip = crear_mapa(filas, columnas)

    lista_carreras.append(
      Carrera(x["round"], x["name"], x["date"], x["circuit"],
              finalizar_carrera(lista_pilotos), mapa_vip, mapa_general))

    circuito = x["circuit"]
    for key, value in circuito.items():
      locacion = circuito["location"]
    for value2 in locacion.values():
      pass
    lista_locacion.append(
      Locacion(x["round"], x["name"], x["date"], x["circuit"],
               finalizar_carrera(lista_pilotos), "mapa", "mapa",
               circuito["circuitId"], circuito["name"], circuito["location"],
               locacion["lat"], locacion["long"], locacion["locality"],
               locacion["country"]))
    lista_circuitos.append(
      Circuito(x["round"], x["name"], x["date"], x["circuit"],
               finalizar_carrera(lista_pilotos), "mapa", "mapa",
               circuito["circuitId"], circuito["name"], circuito["location"]))
    restaurante = x["restaurants"]
    for y in restaurante:

      nombre_restaurante = y["name"]
      alimentos = y["items"]

      lista_restaurantes.append(Restaurante(nombre_restaurante, alimentos))
      for z in alimentos:

        tipo = z["type"].split(":")
        lista_comida.append(Comida(z["name"], z["type"], z["price"]))

        if tipo[1] == "fast":

          lista_alimento_fast.append(
            Alimento(z["name"], tipo[0], z["price"], tipo[1]))
        if tipo[1] == "restaurant":

          lista_alimento_restaurant.append(
            Alimento(z["name"], tipo[0], z["price"], tipo[1]))
        if tipo[1] == "not-alcoholic":

          lista_bebida_noalcohol.append(
            Bebida(z["name"], tipo[0], z["price"], tipo[1]))
        if tipo[1] == "alcoholic":
          lista_bebida_alcohol.append(
            Bebida(z["name"], tipo[0], z["price"], tipo[1]))


"--------------------------------------------------"


def main():
  ''' Ejecuta el menu principal del sistema '''
  url1 = "https://raw.githubusercontent.com/Algorimtos-y-Programacion-2223-2/api-proyecto/main/drivers.json"
  url2 = "https://raw.githubusercontent.com/Algorimtos-y-Programacion-2223-2/api-proyecto/main/constructors.json"
  url3 = "https://raw.githubusercontent.com/Algorimtos-y-Programacion-2223-2/api-proyecto/main/races.json"
  response1 = requests.get(url1)
  response2 = requests.get(url2)
  response3 = requests.get(url3)
  estructura_de_datos_pilotos = response1.json()
  estructura_de_datos_constructores = response2.json()
  estructura_de_datos_carreras = response3.json()
  edc = estructura_de_datos_constructores
  edp = estructura_de_datos_pilotos
  edca = estructura_de_datos_carreras
  lista_constructores = []
  lista_pilotos = []
  lista_carreras = []
  lista_circuitos = []
  lista_locacion = []
  lista_bebida_noalcohol = []
  lista_bebida_alcohol = []
  lista_alimento_fast = []
  lista_alimento_restaurant = []
  lista_comida = []
  lista_restaurantes = []
  boletos = []
  clientes = []

  pasar_estructura_a_objetos(edc, edp, edca, lista_constructores,
                             lista_pilotos, lista_carreras, lista_circuitos,
                             lista_locacion, lista_comida,
                             lista_bebida_noalcohol, lista_bebida_alcohol,
                             lista_alimento_fast, lista_alimento_restaurant,
                             lista_restaurantes)

  while True:
    print("\n--- BIENVENIDO AL SISTEMA DE 'Fórmula 1 2023'---")
    menu = input("""
    --- MENU PRINCIPAL ---
    
    ¿Que desea hacer?
    
    1-Gestión de carreras y equipo
    2-Gestión de venta de entradas
    3-Gestión de asistencia a las carreras
    4-Gestión de restaurantes
    5-Gestión de venta de restaurantes
    6-Indicadores de gestión (estadísticas)
    7-Salir
    
    Ingrese el numero correspondiente a la opcion a elegir
    >>""")
    while menu != "1" and menu != "2" and menu != "3" and menu != "4" and menu != "5" and menu != "6" and menu != "7":
      menu = input("""
    Ingreso invalido!!
    Porfavor seleccione una de las siguientes opciones:
    1-Gestión de carreras y equipo
    2-Gestión de venta de entradas
    3-Gestión de asistencia a las carreras
    4-Gestión de restaurantes
    5-Gestión de venta de restaurantes
    6-Indicadores de gestión (estadísticas)
    7-Salir
    >>""")
    if menu == "1":
      menucarrera = input("""
    --- MENU GESTION DE CARRERAS Y EQUIPO ---\n
    Seleccione una de las siguientes opciones:
    1-Buscar los constructores por país
    2-Buscar los pilotos por constructor
    3-Buscar a las carreras por país del circuito
    4-Buscar todas las carreras que ocurran en un mes
    5-Finalizar carrera
    6-Regresar
    >>""")
      while menucarrera != "1" and menucarrera != "2" and menucarrera != "3" and menucarrera != "4" and menucarrera != "5" and menucarrera != "6":
        menucarrera = input("""
    Ingreso invalido!!
    Porfavor seleccione una de las siguientes opciones:
    1-Buscar los constructores por país
    2-Buscar los pilotos por constructor
    3-Buscar a las carreras por país del circuito
    4-Buscar todas las carreras que ocurran en un mes
    5-Finalizar carrera
    6-Regresar
    >>""")

      if menucarrera == "1":
        buscar_constructores_por_país(edc, lista_constructores)

      elif menucarrera == "2":
        buscar_pilotos_por_constructor(edp, edc, lista_pilotos,
                                       lista_constructores)
      elif menucarrera == "3":
        buscar_carreras_por_pais_del_circuito(edca, lista_locacion,
                                              lista_carreras)
      elif menucarrera == "4":
        buscar_carreras_mes(edca, lista_carreras, lista_locacion)
      elif menucarrera == "5":
        menu_finalizar_carrera = input("""
    --- MENU FINALIZAR CARRERA ---\n
    Seleccione una de las siguientes opciones:
    1-Ver podium por carrera
    2-Finalizar temporada
    3-Ver campeón mundial de la Formula 1 2023
    4-Ver campeón de constructores de la Formula 1 2023
    5-Regresar
    >>""")
        while menu_finalizar_carrera != "1" and menu_finalizar_carrera != "2" and menu_finalizar_carrera != "3" and menu_finalizar_carrera != "4" and menu_finalizar_carrera != "5":
          menu_finalizar_carrera = input("""
    Ingreso invalido!!
    Porfavor seleccione una de las siguientes opciones:
    1-Ver podium por carrera
    2-Finalizar temporada
    3-Ver campeón mundial de la Formula 1 2023
    4-Ver campeón de constructores de la Formula 1 2023
    5-Regresar
    >>""")
        if menu_finalizar_carrera == "1":
          ver_temporada(lista_carreras, lista_pilotos)
        elif menu_finalizar_carrera == "2":
          finalizar_temporada(lista_carreras, lista_pilotos)
        elif menu_finalizar_carrera == "3":
          asignar_campeon(lista_carreras, lista_pilotos)
        elif menu_finalizar_carrera == "4":
          asignar_campeon_constructor(lista_carreras, lista_pilotos,
                                      lista_constructores)
        elif menu_finalizar_carrera == "5":
          continue

      elif menucarrera == "6":
        pass
    elif menu == "2":
      solicitar_datos(lista_locacion, edca, lista_carreras)
    elif menu == "3":
      menugestion(boletos)
      validar_boleto(boletos)
      print("\n")
    elif menu == "4":
      menurestaurante = input("""
    --- MENU GESTION DE RESTAURANTES ---
    
    Seleccione una de las siguientes opciones:
    1-Buscar productos por nombre
    2-Buscar productos por tipo
    3-Buscar productos por rango de precio
    4-Regresar
    >>""")

      while menurestaurante != "1" and menurestaurante != "2" and menurestaurante != "3" and menurestaurante != "4":
        menurestaurante = input("""
    Ingreso invalido!!
    Porfavor seleccione una de las siguientes opciones:
    1-Buscar productos por nombre
    2-Buscar productos por tipo
    3-Buscar productos por rango de precio
    4-Regresar
    >>""")
      if menurestaurante == "1":
        buscar_por_nombre(edca, lista_comida, lista_bebida_noalcohol,
                          lista_bebida_alcohol, lista_alimento_fast,
                          lista_alimento_restaurant)
      elif menurestaurante == "2":
        buscar_por_tipo(edca, lista_comida, lista_bebida_noalcohol,
                        lista_bebida_alcohol, lista_alimento_fast,
                        lista_alimento_restaurant)
      elif menurestaurante == "3":
        buscar_rango_de_precio(edca, lista_comida, lista_bebida_noalcohol,
                               lista_bebida_alcohol, lista_alimento_fast,
                               lista_alimento_restaurant)
      elif menurestaurante == "4":
        pass

    elif menu == "5":
      validar_cliente(lista_comida, lista_restaurantes, clientes)

    elif menu == "6":
      menuestadisticas = input("""
    --- MENU DE ESTADISTICAS ---
    
    Seleccione una de las siguientes opciones:\n
    1-¿Cuál es el promedio de gasto de un cliente VIP en una carrera (ticket + restaurante)?
    2-Tabla con la asistencia a las carreras de mejor a peor
    3-¿Cuál fue la carrera con mayor asistencia?
    4-¿Cuál fue la carrera con mayor boletos vendidos?
    5-Top 3 productos más vendidos en el restaurante.
    6-Top 3 de clientes (clientes que más compraron boletos)
    7-Gráficos
    8-Regresar
    >>""")

      while menuestadisticas != "1" and menuestadisticas != "2" and menuestadisticas != "3" and menuestadisticas != "4" and menuestadisticas != "5" and menuestadisticas != "6" and menuestadisticas != "7" and menuestadisticas != "8":
        menuestadisticas = input("""
    \nIngreso invalido!!
    Porfavor seleccione una de las siguientes opciones:\n
    1-¿Cuál es el promedio de gasto de un cliente VIP en una carrera (ticket + restaurante)?
    2-Tabla con la asistencia a las carreras de mejor a peor
    3-¿Cuál fue la carrera con mayor asistencia?
    4-¿Cuál fue la carrera con mayor boletos vendidos?
    5-Top 3 productos más vendidos en el restaurante.
    6-Top 3 de clientes (clientes que más compraron boletos)
    7-Gráficos
    8-Regresar
    >>""")
      if menuestadisticas == "1":
        promedio_gasto_cliente_vip()
      elif menuestadisticas == "2":
        asistencia_carreras(lista_carreras, lista_locacion)
      elif menuestadisticas == "3":
        carrera_mayor_asistencia(lista_carreras, lista_locacion)
      elif menuestadisticas == "4":
        carrera_mayor_boletos_vendidos(lista_carreras, lista_locacion)
      elif menuestadisticas == "5":
        top_3_productos_mas_vendidos_restaurante(clientes, lista_comida)
      elif menuestadisticas == "6":
        top_3_clientes_que_mas_compraron_boletos(lista_carreras,
                                                 lista_locacion)
      elif menuestadisticas == "7":
        grafico()
      elif menuestadisticas == "8":
        pass

    elif menu == "7":
      break


main()
