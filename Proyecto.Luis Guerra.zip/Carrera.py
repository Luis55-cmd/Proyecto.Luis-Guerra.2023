class Carrera:

  def __init__(self, round, name, date, circuit, podium, mapa_vip,
               mapa_general):
    self.round = round
    self.name = name
    self.date = date
    self.circuit = circuit
    self.podium = podium
    self.mapa_vip = mapa_vip
    self.mapa_general = mapa_general

  def mostrar(self):
    print(
      ("-" * 30) + f"\nRound: {self.round}\n" + ("-" * 30) +
      f"\n > Nombre: {self.name}\n > Fecha: {self.date}\n > Circuito: {self.circuit}\n > Podium: {self.podium}\n > Mapa VIP:  {self.mapa_vip}\n > Mapa general: {self.mapa_general}\n"
    )

  def mostrar_podium(self):
    for i, x in enumerate(self.podium):
      print("-", str(i + 1) + "º clasificado")
      x.mostrar()


class Circuito(Carrera):

  def __init__(self, round, name, date, circuit, podium, mapa_vip,
               mapa_general, circuitId, name_c, location):
    super().__init__(round, name, date, circuit, podium, mapa_vip,
                     mapa_general)
    self.circuitId = circuitId
    self.name_c = name_c
    self.location = location

  def mostrar(self):
    print(
      f"\n > Circuito ID: {self.circuitId}\n > Nombre del circuito: {self.name_c}\n"
    )


class Locacion(Circuito):

  def __init__(self, round, name, date, circuit, podium, mapa_vip,
               mapa_general, circuitId, name_c, location, lat, long, locality,
               country):
    super().__init__(round, name, date, circuit, podium, mapa_vip,
                     mapa_general, circuitId, name_c, location)
    self.lat = lat
    self.long = long
    self.locality = locality
    self.country = country

  def mostrar(self):
    print(
      ("-" * 30) + f"\nRound: {self.round}\n" + ("-" * 30) +
      f"\n > Nombre: {self.name}\n > Fecha: {self.date}\n > Circuito ID: {self.circuitId}\n > Nombre del circuito: {self.name_c}\n > Latitud: {self.lat}\n > Longitud: {self.long}\n > Localidad: {self.locality}\n > Pais: {self.country}\n"
    )
