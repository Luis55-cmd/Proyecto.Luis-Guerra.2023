from Boleto import Boleto


def menugestion(boletos):
  ''' Ejecuta el menu de "Gestión de asistencia a las carreras" '''

  print("\n\t--- MENU GESTION DE ASISTENCIA A LAS CARRERAS ---")
  menu_asistencia = input("""
    1-Ingresar a la carrera
    2-Regresar
    >>""")
  while menu_asistencia != "1" and menu_asistencia != "2":
    menu_asistencia = input("""
    Ingreso invalido!!
    Porfavor seleccione una de las siguientes opciones:
    1-Ingresar a la carrera
    2-Regresar
    >>""")
  if menu_asistencia == "1":
    ingresar_boleto = input("\nIngrese el codigo del boleto: ")
    while len(ingresar_boleto) != 5:
      ingresar_boleto = input(
        "Ingreso, invalido porfavor ingrese el codigo del boleto: ")
    boletos = validar_boleto(boletos)
    existe = validar_codigo(boletos, ingresar_boleto)
    asistencia = validar_asistencia(boletos, ingresar_boleto)
    if existe and not asistencia:
      cambiar_asistencia(boletos, ingresar_boleto)
      print("\nBoleto ingresado con exito!!")
    else:
      print("\nEl boleto ya ingreso a la carrera o el codigo no es valido!!")

    with open("db.txt") as db:
      datos = db.readlines()
    for i, dato in enumerate(datos):
      factura = dato[:-1].split("//")
      if str(ingresar_boleto) == factura[7]:
        ne = i + 1
        with open("db.txt") as dbe:
          datos = dbe.readlines()
        for i, dato in enumerate(datos):
          if i == (ne - 1):
            e = dato[:-1].split("//")

            aux = e
        for boleto in boletos:
          if ingresar_boleto == boleto.codigo_aletorio:
            bol = boleto.asistencia
        aux[8] = bol

        with open("db.txt") as dbe:
          datos = dbe.readlines()
        for i in range(len(datos)):
          if i == (ne - 1):
            datos[
              ne -
              1] = f"{aux[0]}//{aux[1]}//{aux[2]}//{aux[3]}//{aux[4]}//{aux[5]}//{aux[6]}//{aux[7]}//{aux[8]}//{aux[9]}\n"
            with open("db.txt", "w") as dbe:

              dbe.writelines(datos)
        db.close()
  else:
    pass


def validar_boleto(boletos):
  ''' Crea una lista de objetos boletos "Gestión de asistencia a las carreras"'''
  try:
    with open("db.txt") as db:
      datos = db.readlines()
    if len(datos) == 0:
      print("\nTodavía no hay ningúna compra.\n")
    else:
      for dato in datos:
        boleto = dato[:-1].split("//")
        boletos.append(
          Boleto(boleto[0], boleto[1], boleto[2], boleto[3], boleto[4],
                 boleto[5], boleto[6], boleto[7], boleto[8]))

  except FileNotFoundError:
    print("\nTodavía no hay ningúna compra.\n")
  db.close()
  return boletos


def validar_codigo(boletos, ingresar_boleto):
  ''' Valida que el codigo ingresado pertenezca a un boleto "Gestión de asistencia a las carreras"'''
  for ticket in boletos:
    if ticket.codigo_aletorio == ingresar_boleto:
      return True
  return False


def validar_asistencia(boletos, ingresar_boleto):
  ''' Verifica si ya el boleto fue utilizado "Gestión de asistencia a las carreras"'''

  for ticket in boletos:
    if ticket.codigo_aletorio == ingresar_boleto and ticket.asistencia == True:
      return True


def cambiar_asistencia(boletos, ingresar_boleto):
  ''' Cambia el estado de asistencia de un boleto "Gestión de asistencia a las carreras"'''

  for ticket in boletos:
    if ticket.codigo_aletorio == ingresar_boleto:
      ticket.asistencia = True
      return
