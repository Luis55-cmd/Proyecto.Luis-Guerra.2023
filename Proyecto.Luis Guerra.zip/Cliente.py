class Cliente:

  def __init__(self, cedula, comidas_compradas):
    self.cedula = cedula
    self.comidas_compradas = []
