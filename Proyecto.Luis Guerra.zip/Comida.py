class Comida:
  cantidad = 10

  def __init__(self, nombre_comida, tipo_comida, precio):
    self.nombre_comida = nombre_comida
    self.tipo_comida = tipo_comida
    self.precio = (float(precio) * 0.16) + float(precio)

  def mostrar(self):
    print(
      f"\n > Nombre de la comida: {self.nombre_comida}\n > Tipo de comida: {self.tipo_comida}\n > Precio con IVA: {self.precio}$\n > Cantidad de producto: {self.cantidad}\n"
    )


class Bebida(Comida):

  def __init__(self, nombre_comida, tipo_comida, precio, alcoholica):
    super().__init__(nombre_comida, tipo_comida, precio)
    self.alcoholica = alcoholica

  def mostrar(self):
    print(
      f"\n > Nombre de la comida: {self.nombre_comida}\n > Tipo de comida: {self.tipo_comida}\n > Precio con IVA: {self.precio}$\n > Tipo de bebida: {self.alcoholica}\n"
    )


class Alimento(Comida):

  def __init__(self, nombre_comida, tipo_comida, precio, empaque):
    super().__init__(nombre_comida, tipo_comida, precio)
    self.empaque = empaque

  def mostrar(self):
    print(
      f"\n > Nombre de la comida: {self.nombre_comida}\n > Tipo de comida: {self.tipo_comida}\n > Precio con IVA: {self.precio}$\n > Tipo de alimento: {self.empaque}\n"
    )
