class Constructor:

  def __init__(self, id, name, nationality, ref_pilotos, puntaje):
    self.id = id
    self.name = name
    self.nationality = nationality
    self.ref_pilotos = ref_pilotos
    self.puntaje = puntaje

  def mostrar(self):
    print(("-" * 30) + f"\n{self.id}\n" + ("-" * 30) +
          f"\n > Nombre: {self.name}\n > Nacionalidad: {self.nationality}\n")
