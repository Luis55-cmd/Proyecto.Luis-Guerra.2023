class Restaurante:

  def __init__(self, name, items):
    self.name = name
    self.items = items

  def mostrar_items(self):
    print(("-" * 50) + f"\nRestaurante: {self.name}\n" + ("-" * 50))
    for i, z in enumerate(self.items):
      nombre_comida = z["name"]
      tipo_comida = z["type"]
      precio = z["price"]
      precio = (float(precio) * 0.16) + float(precio)
      print(
        f"\n > #{i+1}\n > Nombre de la comida: {nombre_comida}\n > Tipo de comida: {tipo_comida}\n > Precio: {precio}$\n "
      )
