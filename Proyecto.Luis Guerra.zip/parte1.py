from Constructor import Constructor
from Carrera import Carrera, Locacion, Circuito
from Piloto import Piloto
import random


def buscar_constructores_por_país(edc, lista_constructores):
  ''' Muestra los constructores de un pais "Gestion de carreras y equipos" '''
  paises = []
  for x in edc:
    paises.append(x["nationality"])
  for pais in paises:
    if paises.count(pais) > 1:
      paises.remove(pais)
  print("\n\t----Paises de los constructores----")
  for i, pais in enumerate(paises):
    print(f"\t{i + 1}-{pais}")
  seleccion = input("""
    Ingrese el numero correspondiente al pais a elegir:
    >>""")
  while (not seleccion.isnumeric()) or (int(seleccion) < 1) or (int(seleccion)
                                                                > 7):
    seleccion = input("""
    Ingreso, invalido!!
    Porfavor ingrese el numero correspondiente al pais a elegir:
    >>""")
  seleccion = int(seleccion)
  for i, pais in enumerate(paises):
    if seleccion == i + 1:
      seleccion = pais
  print(f"\nEstos son los constructores de {seleccion}: \n")
  for i, x in enumerate(lista_constructores):
    if seleccion == x.nationality:
      print("-", i + 1)
      x.mostrar()


def buscar_pilotos_por_constructor(edp, edc, lista_pilotos,
                                   lista_constructores):
  ''' Muestra los pilotos de un constructor "Gestion de carreras y equipos" '''
  print("----Estos son los constructores----")
  for i, x in enumerate(lista_constructores):
    print(f"\n-{i + 1}")
    x.mostrar()
  seleccion = input("""
    Ingrese el numero correspondiente al constructor a elegir:
    >>""")
  while (not seleccion.isnumeric()) or (int(seleccion) < 1) or (int(seleccion)
                                                                > 10):
    seleccion = input("""
    Ingreso, invalido!!
    Porfavor ingrese el numero correspondiente al constructor a elegir:
    >>""")
  seleccion = int(seleccion)
  for i, constructor in enumerate(lista_constructores):
    if seleccion == i + 1:
      seleccion = constructor.id
  print(f"Estos son los pilotos del constructor {seleccion}")
  for i, piloto in enumerate(lista_pilotos):
    if seleccion == piloto.team:
      print(f"\n-{i + 1}")
      piloto.mostrar()


def buscar_carreras_por_pais_del_circuito(edca, lista_locacion,
                                          lista_carreras):
  ''' Muestra las carreras de un pais del circuito "Gestion de carreras y equipos" '''
  print("\n----Estos son los paises de cada circuito----\n")
  for i, x in enumerate(lista_locacion):
    print(i + 1, "-", x.circuit["location"]["country"])

  seleccion = input("""
  Ingrese el numero correspondiente al pais que desea ver las carreras:
  >>""")
  while (not seleccion.isnumeric()) or (int(seleccion) < 1) or (int(seleccion)
                                                                > 23):
    seleccion = input("""
  Ingreso, invalido!!
  Porfavor ingrese el numero correspondiente al pais que desea ver las carreras:
  >>""")
  seleccion = int(seleccion)

  for i, pais in enumerate(lista_carreras):
    if seleccion == i + 1:
      seleccion = pais.circuit["location"]["country"]
  print(f"\n\nEstas son las carreras de {seleccion}")
  for i, carrera in enumerate(lista_locacion):
    if seleccion == carrera.circuit["location"]["country"]:
      carrera.mostrar()
  print("\n")


def buscar_carreras_mes(edca, lista_carreras, lista_locacion):
  ''' Muestra las carreras de un mes "Gestion de carreras y equipos" '''
  seleccion = input("""
    Ingrese el numero correspondiente al mes que desea ver las carreras
    
    --- Duracion de meses del evento ---
    1-Marzo
    2-Abril
    3-Mayo
    4-Junio
    5-Julio
    6-Agosto
    7-Septiembre
    8-Octubre
    9-Noviembre
    >>""")
  while (not seleccion.isnumeric()) or (int(seleccion) < 1) or (int(seleccion)
                                                                > 9):
    seleccion = input("""
    Ingreso, invalido!!
    Porfavor ingrese el numero correspondiente al mes que desea ver las carreras:
    >>""")

  if seleccion == "1":
    fecha = "Marzo"
    seleccion = "03"
  elif seleccion == "2":
    fecha = "Abril"
    seleccion = "04"
  elif seleccion == "3":
    fecha = "Mayo"
    seleccion = "05"
  elif seleccion == "4":
    fecha = "Junio"
    seleccion = "06"
  elif seleccion == "5":
    fecha = "Julio"
    seleccion = "07"
  elif seleccion == "6":
    fecha = "Agosto"
    seleccion = "08"
  elif seleccion == "7":
    fecha = "Septiembre"
    seleccion = "09"
  elif seleccion == "8":
    fecha = "Octubre"
    seleccion = "10"
  elif seleccion == "9":
    fecha = "Noviembre"
    seleccion = "11"
  print(f"\n\nEstas son las carreras de {fecha}:\n")
  for i, x in enumerate(lista_locacion):
    if x.date.split("-")[1] == seleccion:
      x.mostrar()


def finalizar_carrera(lista_pilotos):
  ''' Finaliza las carreras y asigna un podium de pilotos a cada una  de ellas "Gestion de carreras y equipos" '''
  podium = random.sample(lista_pilotos, 10)

  return podium


def ver_temporada(lista_carreras, lista_pilotos):
  ''' Muestra el podium de los pilotos en las 23 carreras "Gestion de carreras y equipos" '''
  for x in lista_carreras:
    print("---------------", "Carrera", x.round, "---------------\n")
    x.mostrar_podium()


def finalizar_temporada(lista_carreras, lista_pilotos):
  ''' Finaliza la temporada y asigna un puntaje a los pilotos en cada carrera "Gestion de carreras y equipos" '''

  for y in lista_carreras:
    for i, x in enumerate(y.podium):

      if i + 1 == 1:
        x.puntaje += 25
      elif i + 1 == 2:
        x.puntaje += 18
      elif i + 1 == 3:
        x.puntaje += 15
      elif i + 1 == 4:
        x.puntaje += 12
      elif i + 1 == 5:
        x.puntaje += 10
      elif i + 1 == 6:
        x.puntaje += 8
      elif i + 1 == 7:
        x.puntaje += 6
      elif i + 1 == 8:
        x.puntaje += 4
      elif i + 1 == 9:
        x.puntaje += 2
      elif i + 1 == 10:
        x.puntaje += 1
    for x in lista_pilotos:
      if x not in y.podium:
        x.puntaje = 0
  piloto_campeon = []

  for x in lista_pilotos:
    piloto_campeon.append(x.puntaje)
  print("\nTEMPORADA FINALIZADA !! \n")
  return piloto_campeon


def asignar_campeon(lista_carreras, lista_pilotos):
  ''' Muestra al campeon mundial de la Formula 1 2023 "Gestion de carreras y equipos" '''
  print("\n")

  piloto_campeon = finalizar_temporada(lista_carreras, lista_pilotos)

  print("\n\t--- CAMPEON MUNDIAL ---\n")
  for x in lista_pilotos:
    if max(piloto_campeon) == x.puntaje:
      x.mostrar()
      print(f" > Puntaje final: {x.puntaje}\n")
  print("-" * 40)
  print("\n")


def asignar_campeon_constructor(lista_carreras, lista_pilotos,
                                lista_constructores):
  ''' Asigna puntajes y muestra al campeon de constructores de la Formula 1 2023 "Gestion de carreras y equipos" '''

  for i, x in enumerate(lista_constructores):
    for i, piloto in enumerate(lista_pilotos):
      if x.id == piloto.team:
        x.puntaje += piloto.puntaje

  constructor_campeon = []
  for x in lista_constructores:
    constructor_campeon.append(x.puntaje)

  if max(constructor_campeon) == 0:
    print(
      "\nERROR!!. Todavia no se ha finalizado la temporada, porfavor finalize la temporada para ver al ganador\n"
    )
  else:
    print("\n\t--- CAMPEON DE CONSTRUCTORES ---\n")
    for x in lista_constructores:

      if max(constructor_campeon) == x.puntaje:
        x.mostrar()
        print(f" > Puntaje final: {x.puntaje}\n")
    print("-" * 40)
    print("\n")
