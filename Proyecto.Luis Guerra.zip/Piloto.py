class Piloto:

  def __init__(self, id, permanentNumber, code, team, firstName, lastName,
               dateOfBirth, nationality, puntaje):
    self.id = id
    self.permanentNumber = permanentNumber
    self.code = code
    self.team = team
    self.firstName = firstName
    self.lastName = lastName
    self.dateOfBirth = dateOfBirth
    self.nationality = nationality
    self.puntaje = puntaje

  def mostrar(self):
    print(
      ("-" * 30) + f"\n{self.id}\n" + ("-" * 30) +
      f"\n > Nombre: {self.firstName}\n > Apellido: {self.lastName}\n > Team: {self.team}\n > Fecha de nacimiento: {self.dateOfBirth}\n > Lugar de nacimiento: {self.nationality}\n > Numero permanente: {self.permanentNumber}\n"
    )
