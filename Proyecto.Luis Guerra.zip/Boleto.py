class Boleto:

  def __init__(self, nombre, cedula, edad, num_de_carrera, tip_entrada, total,
               asiento, codigo_aletorio, asistencia):
    self.nombre = nombre
    self.cedula = cedula
    self.edad = edad
    self.num_de_carrera = num_de_carrera
    self.tip_entrada = tip_entrada
    self.total = total
    self.asiento = asiento
    self.codigo_aletorio = codigo_aletorio
    self.asistencia = asistencia

  def mostrar(self):
    print(
      ("-" * 30) +
      f" > \n Codigo del boleto: {self.codigo_aletorio}\n > Nombre: {self.nombre}\n > Cedula: {self.cedula}\n > Edad: {self.edad}\n > Numero de carrera: {self.num_de_carrera}\n > Tipo de entrada: {self.tip_entrada}\n > Total a pagar: {self.total}$\n > Asiento: {self.asiento}\n > Asistencia: {self.asistencia}\n"
      + ("-" * 30))