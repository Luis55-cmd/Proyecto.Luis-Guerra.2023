def buscar_rango_de_precio(edca, lista_comida, lista_bebida_noalcohol,
                           lista_bebida_alcohol, lista_alimento_fast,
                           lista_alimento_restaurant):
  ''' Muestra los productos en un rango de precio "Gestion de restaurantes" '''

  rango_inicial = input("Ingrese el rango de precio minimo que desea buscar: ")
  while (not rango_inicial.isnumeric()):
    rango_inicial = input(
      "Ingreso ivalido, porfavor ingrese el rango de precio minimo que desea buscar: "
    )
  rango_final = input("Ingrese el rango de precio maximo que desea buscar: ")
  while (not rango_final.isnumeric()):
    rango_final = input(
      "Ingreso ivalido, porfavor ingrese el rango de precio maximo que desea buscar: "
    )
  rango_inicial = int(rango_inicial)
  rango_final = int(rango_final)
  for i, x in enumerate(lista_comida):
    if x.precio > rango_inicial and x.precio < rango_final:
      print(f"\n-{i + 1}")
      x.mostrar()


def buscar_por_tipo(edca, lista_comida, lista_bebida_noalcohol,
                    lista_bebida_alcohol, lista_alimento_fast,
                    lista_alimento_restaurant):
  ''' Muestra los productos por su tipo "Gestion de restaurantes" '''
  print("----Estos son los tipos de productos----")
  seleccion = input("""
  Ingrese el tipo de producto que desea buscar:
  1-Bebida
  2-Alimentos
  >>""")
  while seleccion != "1" and seleccion != "2":
    seleccion = input("""
  Ingreso invalido!!
  Porfavor seleccione una de las siguientes opciones:
  1-Bebida
  2-Alimentos
  >>""")
  if seleccion == "1":
    seleccion2 = input("""
  Ingrese el tipo de bebida que desea buscar:
  1-Con alcohol
  2-Sin alcohol
  >>""")
    while seleccion2 != "1" and seleccion2 != "2":
      seleccion2 = input("""
    Ingreso invalido!!
    Porfavor seleccione una de las siguientes opciones:
    1-Con alcohol
    2-Sin alcohol
    >>""")
    if seleccion2 == "1":
      for i, x in enumerate(lista_bebida_alcohol):
        print(f"\n-{i + 1}")
        x.mostrar()
    elif seleccion2 == "2":
      for i, x in enumerate(lista_bebida_noalcohol):
        print(f"\n-{i + 1}")
        x.mostrar()
  elif seleccion == "2":
    seleccion2 = input("""
  Ingrese el tipo de alimento que desea buscar:
  1-De empaque
  2-De preparacion
  >>""")
    while seleccion2 != "1" and seleccion2 != "2":
      seleccion2 = input("""
    Ingreso invalido!!
    Porfavor seleccione una de las siguientes opciones:
    1-De empaque
    2-De preparacion
    >>""")
    if seleccion2 == "1":
      for i, x in enumerate(lista_alimento_fast):
        print(f"\n-{i + 1}")
        x.mostrar()
    elif seleccion2 == "2":
      for i, x in enumerate(lista_alimento_restaurant):
        print(f"\n-{i + 1}")
        x.mostrar()


def buscar_por_nombre(edca, lista_comida, lista_bebida_noalcohol,
                      lista_bebida_alcohol, lista_alimento_fast,
                      lista_alimento_restaurant):
  ''' Muestra los productos por sus nombres "Gestion de restaurantes" '''
  print("----Estos son los nombres de los productos----")

  for i, x in enumerate(lista_comida):
    print(f"\n-{i + 1}")
    print("Nombre de la comida: ", x.nombre_comida)
  seleccion = input("""
  Ingrese el numero correspondiente al producto a elegir:
  >>""")
  while (not seleccion.isnumeric()) or (int(seleccion) < 1) or (int(seleccion)
                                                                > 583):
    seleccion = input("""
  Ingreso, invalido!!
  Porfavor ingrese el numero correspondiente al producto a elegir:
  >>""")
  seleccion = int(seleccion)
  for i, x in enumerate(lista_comida):
    if seleccion == i + 1:
      x.mostrar()
