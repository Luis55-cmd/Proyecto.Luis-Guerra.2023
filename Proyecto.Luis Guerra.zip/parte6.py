import random
import matplotlib
import matplotlib.pyplot as p
from Constructor import Constructor
from Carrera import Carrera, Locacion, Circuito
from Piloto import Piloto
from Restaurante import Restaurante
from Comida import Comida, Bebida, Alimento
from Boleto import Boleto
from Cliente import Cliente


def grafico():
  print(
    "\nLos graficos estan anexados en el archivo.zip como pngs y se generan cada vez que el usuario marca una opcion del 'MENU DE ESTADISTICAS' \n"
  )


def top_3_clientes_que_mas_compraron_boletos(lista_carreras, lista_locacion):
  ''' Devuelve el top 3 de clientes que mas compraron boletos "Indicadores de gestion" '''
  try:
    with open("db.txt") as db:
      datos = db.readlines()
    if len(datos) == 0:
      print("\nTodavía no hay ningúna compra.\n")
    else:
      pass

  except FileNotFoundError:
    print("\nTodavía no hay ningúna compra.\n")
  ''' Top 3 de clientes (clientes que más compraron boletos) '''

  clientes = {}
  for dato in datos:
    factura = dato[:-1].split("//")
    b = [int(x) for x in factura[3].split(",")]
    clientes[factura[0]] = b

  cantidad = []
  for k, v in clientes.items():
    cantidad.append(len(v))

  if len(cantidad) == 0:
    print("NO SE HAN COMPRADO ENTRADAS")
  else:
    dic = {}
    y = []
    x = []
    cantidad.sort()
    for k, v in clientes.items():
      if cantidad[-1] == len(v) or cantidad[-2] == len(
          v) or cantidad[-3] == len(v):
        dic[k] = len(v)
        x.append(k)
        y.append(len(v))

  p.ylabel("CANTIDAD DE ENTRADAS")
  p.xlabel("CLIENTES")
  p.bar(x, y)
  p.savefig("grafico6.png")
  print("\n--- TOP 3 CLIENTES QUE MAS COMPRARON BOLETOS ---\n\n")
  dic = sorted(dic.items(), key=lambda x: x[1], reverse=True)
  for i, x in enumerate(dic):
    if i < 3:
      print("----------", i + 1, "-----------\n")
      print("\t\t", x[0], "\n")
  print("-------------------------\n")
  db.close()


def top_3_productos_mas_vendidos_restaurante(clientes, lista_comida):
  ''' Devuelve el top 3 de productos mas vendidos en el restaurante "Indicadores de gestion" '''

  cantidades = []
  for x in lista_comida:
    cantidades.append(x.cantidad)

  cantidades.sort()

  if cantidades[0] == 10:
    if cantidades[1] == 10:
      if cantidades[2] == 10:
        print("NO SE HAN VENDIDO PRODUCTOS")

  else:
    print("\n--- TOP 3 PRODUCTOS MAS VENDIDOS ---\n")
    y_1 = []

    x_1 = []
    impresos = []
    comidas = []
    for x in lista_comida:
      if x.cantidad == 10:
        continue

      else:

        if x.nombre_comida not in impresos:
          if cantidades[0] == x.cantidad:
            impresos.append(x.nombre_comida)
            comidas.append(x)
            x_1.append(x.nombre_comida)
            y_1.append(x.cantidad)

          elif cantidades[1] == x.cantidad:
            impresos.append(x.nombre_comida)
            comidas.append(x)
            x_1.append(x.nombre_comida)
            y_1.append(x.cantidad)

          elif cantidades[2] == x.cantidad:
            impresos.append(x.nombre_comida)
            comidas.append(x)
            x_1.append(x.nombre_comida)
            y_1.append(x.cantidad)

    p.ylabel("CANTIDAD VENDIDA")
    p.xlabel("PRODUCTOS")
    p.bar(x_1, y_1)
    p.savefig("grafico5.png")

    comidas = sorted(comidas, key=lambda x: x.cantidad)

    for i, x in enumerate(comidas):
      if i < 3:
        print("----------", i + 1, "-----------\n")
        x.mostrar()
        print(f" > Cantidad vendida: {10-x.cantidad}\n")
    print("-------------------------\n")


def carrera_mayor_boletos_vendidos(lista_carreras, lista_locacion):
  ''' Devuelve cual fue la carrera con mayor boletos vendidos "Indicadores de gestion" '''

  try:
    with open("db.txt") as db:
      datos = db.readlines()
    if len(datos) == 0:
      print("\nTodavía no hay ningúna compra.\n")
    else:
      pass

  except FileNotFoundError:
    print("\nTodavía no hay ningúna compra.\n")
  x_1 = []
  lista_boletos = []
  for i, x in enumerate(lista_carreras):
    lista_boletos.append([x.round, []])
    x_1.append(x.round)

  for dato in datos:
    factura = dato[:-1].split("//")
    if factura[3] == "1":
      lista_boletos[0][1].append(factura[3])
    elif factura[3] == "2":
      lista_boletos[1][1].append(factura[3])
    elif factura[3] == "3":
      lista_boletos[2][1].append(factura[3])
    elif factura[3] == "4":
      lista_boletos[3][1].append(factura[3])
    elif factura[3] == "5":
      lista_boletos[4][1].append(factura[3])
    elif factura[3] == "6":
      lista_boletos[5][1].append(factura[3])
    elif factura[3] == "7":
      lista_boletos[6][1].append(factura[3])
    elif factura[3] == "8":
      lista_boletos[7][1].append(factura[3])
    elif factura[3] == "9":
      lista_boletos[8][1].append(factura[3])
    elif factura[3] == "10":
      lista_boletos[9][1].append(factura[3])
    elif factura[3] == "11":
      lista_boletos[10][1].append(factura[3])
    elif factura[3] == "12":
      lista_boletos[11][1].append(factura[3])
    elif factura[3] == "13":
      lista_boletos[12][1].append(factura[3])
    elif factura[3] == "14":
      lista_boletos[13][1].append(factura[3])
    elif factura[3] == "15":
      lista_boletos[14][1].append(factura[3])
    elif factura[3] == "16":
      lista_boletos[15][1].append(factura[3])
    elif factura[3] == "17":
      lista_boletos[16][1].append(factura[3])
    elif factura[3] == "18":
      lista_boletos[17][1].append(factura[3])
    elif factura[3] == "19":
      lista_boletos[18][1].append(factura[3])
    elif factura[3] == "20":
      lista_boletos[19][1].append(factura[3])
    elif factura[3] == "21":
      lista_boletos[20][1].append(factura[3])
    elif factura[3] == "22":
      lista_boletos[21][1].append(factura[3])
    elif factura[3] == "23":
      lista_boletos[22][1].append(factura[3])

  lista_mayor_boletos = []
  y_1 = []
  for x in lista_boletos:
    lista_mayor_boletos.append(len(x[1]))
    y_1.append(len(x[1]))

  p.ylabel("BOLETOS VENDIDOS")
  p.xlabel("CARRERA")
  p.bar(x_1, y_1)
  p.savefig("grafico4.png")

  print("\n --- CARRERA CON MAYOR BOLETOS VENDIDOS ---\n\n")
  for x in lista_boletos:
    for y in lista_locacion:
      if y.round == x[0]:
        if len(x[1]) == max(lista_mayor_boletos):
          y.mostrar()
          print("", ">", "Boletos vendidos:", len(x[1]), "\n")
  print("------------------------------------------------\n")
  db.close()


def carrera_mayor_asistencia(lista_carreras, lista_locacion):
  ''' Devuelve cual fue la carrera con mayor asistencia "Indicadores de gestion" '''
  try:
    with open("db.txt") as db:
      datos = db.readlines()
    if len(datos) == 0:
      print("\nTodavía no hay ningúna compra.\n")
    else:
      pass

  except FileNotFoundError:
    print("\nTodavía no hay ningúna compra.\n")
  x_1 = []
  lista_asistencia = []
  for i, x in enumerate(lista_carreras):
    lista_asistencia.append([x.round, [], []])
    x_1.append(x.round)

  for dato in datos:
    factura = dato[:-1].split("//")
    if factura[8] == "False":
      pass
    elif factura[8] == "True":
      if factura[3] == "1":
        lista_asistencia[0][1].append(factura[8])
        lista_asistencia[0][2].append(factura[0])
      elif factura[3] == "2":
        lista_asistencia[1][1].append(factura[8])
        lista_asistencia[1][2].append(factura[0])
      elif factura[3] == "3":
        lista_asistencia[2][1].append(factura[8])
        lista_asistencia[2][2].append(factura[0])
      elif factura[3] == "4":
        lista_asistencia[3][1].append(factura[8])
        lista_asistencia[3][2].append(factura[0])
      elif factura[3] == "5":
        lista_asistencia[4][1].append(factura[8])
        lista_asistencia[4][2].append(factura[0])
      elif factura[3] == "6":
        lista_asistencia[5][1].append(factura[8])
        lista_asistencia[5][2].append(factura[0])
      elif factura[3] == "7":
        lista_asistencia[6][1].append(factura[8])
        lista_asistencia[6][2].append(factura[0])
      elif factura[3] == "8":
        lista_asistencia[7][1].append(factura[8])
        lista_asistencia[7][2].append(factura[0])
      elif factura[3] == "9":
        lista_asistencia[8][1].append(factura[8])
        lista_asistencia[8][2].append(factura[0])
      elif factura[3] == "10":
        lista_asistencia[9][1].append(factura[8])
        lista_asistencia[9][2].append(factura[0])
      elif factura[3] == "11":
        lista_asistencia[10][1].append(factura[8])
        lista_asistencia[10][2].append(factura[0])
      elif factura[3] == "12":
        lista_asistencia[11][1].append(factura[8])
        lista_asistencia[11][2].append(factura[0])
      elif factura[3] == "13":
        lista_asistencia[12][1].append(factura[8])
        lista_asistencia[12][2].append(factura[0])
      elif factura[3] == "14":
        lista_asistencia[13][1].append(factura[8])
        lista_asistencia[13][2].append(factura[0])
      elif factura[3] == "15":
        lista_asistencia[14][1].append(factura[8])
        lista_asistencia[14][2].append(factura[0])
      elif factura[3] == "16":
        lista_asistencia[15][1].append(factura[8])
        lista_asistencia[15][2].append(factura[0])
      elif factura[3] == "17":
        lista_asistencia[16][1].append(factura[8])
        lista_asistencia[16][2].append(factura[0])
      elif factura[3] == "18":
        lista_asistencia[17][1].append(factura[8])
        lista_asistencia[17][2].append(factura[0])
      elif factura[3] == "19":
        lista_asistencia[18][1].append(factura[8])
        lista_asistencia[18][2].append(factura[0])
      elif factura[3] == "20":
        lista_asistencia[19][1].append(factura[8])
        lista_asistencia[19][2].append(factura[0])
      elif factura[3] == "21":
        lista_asistencia[20][1].append(factura[8])
        lista_asistencia[20][2].append(factura[0])
      elif factura[3] == "22":
        lista_asistencia[21][1].append(factura[8])
        lista_asistencia[21][2].append(factura[0])
      elif factura[3] == "23":
        lista_asistencia[22][1].append(factura[8])
        lista_asistencia[22][2].append(factura[0])

  y_1 = []
  for x in lista_asistencia:
    y_1.append(len(x[1]))

  lista_asistencia = sorted(
    lista_asistencia,
    key=lambda lista_asistencia: len(lista_asistencia[1]),
    reverse=True)

  lista_mayor_asistencia = []

  for x in lista_asistencia:
    lista_mayor_asistencia.append(len(x[1]))

  p.ylabel("ASISTENCIA")
  p.xlabel("CARRERA")
  p.bar(x_1, y_1)
  p.savefig("grafico3y2.png")

  print("\n --- CARRERA CON MAYOR ASISTENCIA ---\n\n")
  for x in lista_asistencia:
    for y in lista_locacion:
      if y.round == x[0]:
        if len(x[1]) == max(lista_mayor_asistencia):

          y.mostrar()
          print("", ">", "Asistencia:", len(x[1]), "personas", "\n")
  print("-----------------------------------------------\n")

  db.close()


def asistencia_carreras(lista_carreras, lista_locacion):
  ''' Devuelve la tabla con la asistencia a las carreras de mejor a peor "Indicadores de gestion" '''
  try:
    with open("db.txt") as db:
      datos = db.readlines()
    if len(datos) == 0:
      print("\nTodavía no hay ningúna compra.\n")
    else:
      pass

  except FileNotFoundError:
    print("\nTodavía no hay ningúna compra.\n")

  lista_boletos = []
  for i, x in enumerate(lista_carreras):
    lista_boletos.append([x.round, []])

  for dato in datos:
    factura = dato[:-1].split("//")
    if factura[3] == "1":
      lista_boletos[0][1].append(factura[3])
    elif factura[3] == "2":
      lista_boletos[1][1].append(factura[3])
    elif factura[3] == "3":
      lista_boletos[2][1].append(factura[3])
    elif factura[3] == "4":
      lista_boletos[3][1].append(factura[3])
    elif factura[3] == "5":
      lista_boletos[4][1].append(factura[3])
    elif factura[3] == "6":
      lista_boletos[5][1].append(factura[3])
    elif factura[3] == "7":
      lista_boletos[6][1].append(factura[3])
    elif factura[3] == "8":
      lista_boletos[7][1].append(factura[3])
    elif factura[3] == "9":
      lista_boletos[8][1].append(factura[3])
    elif factura[3] == "10":
      lista_boletos[9][1].append(factura[3])
    elif factura[3] == "11":
      lista_boletos[10][1].append(factura[3])
    elif factura[3] == "12":
      lista_boletos[11][1].append(factura[3])
    elif factura[3] == "13":
      lista_boletos[12][1].append(factura[3])
    elif factura[3] == "14":
      lista_boletos[13][1].append(factura[3])
    elif factura[3] == "15":
      lista_boletos[14][1].append(factura[3])
    elif factura[3] == "16":
      lista_boletos[15][1].append(factura[3])
    elif factura[3] == "17":
      lista_boletos[16][1].append(factura[3])
    elif factura[3] == "18":
      lista_boletos[17][1].append(factura[3])
    elif factura[3] == "19":
      lista_boletos[18][1].append(factura[3])
    elif factura[3] == "20":
      lista_boletos[19][1].append(factura[3])
    elif factura[3] == "21":
      lista_boletos[20][1].append(factura[3])
    elif factura[3] == "22":
      lista_boletos[21][1].append(factura[3])
    elif factura[3] == "23":
      lista_boletos[22][1].append(factura[3])

  lista_asistencia = []
  for i, x in enumerate(lista_carreras):
    lista_asistencia.append([x.round, [], []])

  for dato in datos:
    factura = dato[:-1].split("//")
    if factura[8] == "False":
      pass
    elif factura[8] == "True":
      if factura[3] == "1":
        lista_asistencia[0][1].append(factura[8])
        lista_asistencia[0][2].append(factura[0])
      elif factura[3] == "2":
        lista_asistencia[1][1].append(factura[8])
        lista_asistencia[1][2].append(factura[0])
      elif factura[3] == "3":
        lista_asistencia[2][1].append(factura[8])
        lista_asistencia[2][2].append(factura[0])
      elif factura[3] == "4":
        lista_asistencia[3][1].append(factura[8])
        lista_asistencia[3][2].append(factura[0])
      elif factura[3] == "5":
        lista_asistencia[4][1].append(factura[8])
        lista_asistencia[4][2].append(factura[0])
      elif factura[3] == "6":
        lista_asistencia[5][1].append(factura[8])
        lista_asistencia[5][2].append(factura[0])
      elif factura[3] == "7":
        lista_asistencia[6][1].append(factura[8])
        lista_asistencia[6][2].append(factura[0])
      elif factura[3] == "8":
        lista_asistencia[7][1].append(factura[8])
        lista_asistencia[7][2].append(factura[0])
      elif factura[3] == "9":
        lista_asistencia[8][1].append(factura[8])
        lista_asistencia[8][2].append(factura[0])
      elif factura[3] == "10":
        lista_asistencia[9][1].append(factura[8])
        lista_asistencia[9][2].append(factura[0])
      elif factura[3] == "11":
        lista_asistencia[10][1].append(factura[8])
        lista_asistencia[10][2].append(factura[0])
      elif factura[3] == "12":
        lista_asistencia[11][1].append(factura[8])
        lista_asistencia[11][2].append(factura[0])
      elif factura[3] == "13":
        lista_asistencia[12][1].append(factura[8])
        lista_asistencia[12][2].append(factura[0])
      elif factura[3] == "14":
        lista_asistencia[13][1].append(factura[8])
        lista_asistencia[13][2].append(factura[0])
      elif factura[3] == "15":
        lista_asistencia[14][1].append(factura[8])
        lista_asistencia[14][2].append(factura[0])
      elif factura[3] == "16":
        lista_asistencia[15][1].append(factura[8])
        lista_asistencia[15][2].append(factura[0])
      elif factura[3] == "17":
        lista_asistencia[16][1].append(factura[8])
        lista_asistencia[16][2].append(factura[0])
      elif factura[3] == "18":
        lista_asistencia[17][1].append(factura[8])
        lista_asistencia[17][2].append(factura[0])
      elif factura[3] == "19":
        lista_asistencia[18][1].append(factura[8])
        lista_asistencia[18][2].append(factura[0])
      elif factura[3] == "20":
        lista_asistencia[19][1].append(factura[8])
        lista_asistencia[19][2].append(factura[0])
      elif factura[3] == "21":
        lista_asistencia[20][1].append(factura[8])
        lista_asistencia[20][2].append(factura[0])
      elif factura[3] == "22":
        lista_asistencia[21][1].append(factura[8])
        lista_asistencia[21][2].append(factura[0])
      elif factura[3] == "23":
        lista_asistencia[22][1].append(factura[8])
        lista_asistencia[22][2].append(factura[0])

  lista_asistencia = sorted(
    lista_asistencia,
    key=lambda lista_asistencia: len(lista_asistencia[1]),
    reverse=True)

  print("\n--------------------------------------------------")
  print("\n --- MEJOR A PEOR ASISTENCIA ---\n\n")

  for x in lista_asistencia:
    for y in lista_locacion:
      if y.round == x[0]:
        print("------ Carrera ", y.round, "------")
        print("", "> Nombre de la carrera: ", y.name)
        print("", "> Circuito: ", y.name_c)
    print("", ">", "Asistencia:", len(x[1]), "personas")
    print("", ">", "Boletos vendidos:", len(x[2]))
    print(
      "", ">",
      f"Relación asistencia/venta: se vendio {len(x[2])} boletos y asistieron {len(x[1])} persona"
    )
    print("", ">", "Personas: ", end="")
    for nombre in x[2]:
      print(nombre, end=", ")

    print("\n\n")
  print("--------------------------------------------------\n")
  db.close()


def promedio_gasto_cliente_vip():
  ''' Devuelve cual es el promedio de gasto de un cliente VIP en una carrera "Indicadores de gestion" '''
  try:
    with open("db.txt") as db:
      datos = db.readlines()
    if len(datos) == 0:
      print("\nTodavía no hay ningúna compra.\n")
    else:
      pass

  except FileNotFoundError:
    print("\nTodavía no hay ningúna compra.\n")
  x_1 = []
  y_1 = []
  precio_clientes_vip = []
  for dato in datos:
    factura = dato[:-1].split("//")
    if "VIP" == factura[4]:
      precio_ticket = factura[5]
      precio_restaurante = factura[9]
      precio_total = float(precio_ticket) + float(precio_restaurante)
      precio_clientes_vip.append(float(precio_total))
      x_1.append(factura[0])
      y_1.append(float(precio_total))

  p.ylabel("GASTO '$'")
  p.xlabel("CLIENTE")
  p.bar(x_1, y_1)
  p.savefig("grafico1.png")

  promedio = 0
  for precio in precio_clientes_vip:
    promedio += float(precio) / len(precio_clientes_vip)
  print(
    f"\n\tEl promedio de gasto de un cliente VIP en una carrera (ticket + restaurante) es: {round(promedio,2)}$\n\n"
  )
  db.close()
